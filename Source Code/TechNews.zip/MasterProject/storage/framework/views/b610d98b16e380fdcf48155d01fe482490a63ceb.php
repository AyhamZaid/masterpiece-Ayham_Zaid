<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">

        <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="./"><img src="<?php echo e(asset('others')); ?>/<?php echo e($shareData['admin_logo']); ?> " alt="Logo"></a>
            <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('admin\images')); ?>/logo2.png" alt="Logo"></a>
        </div>

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="./"> <i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                </li>
                <?php if (\Entrust::can(['Permission Update','All','Permission'])) : ?>
                <li>
                    <a href="<?php echo e(url('/back/permission')); ?> "> <i class="menu-icon fa fa-laptop"></i>Permission </a>
                </li>
                <?php endif; // Entrust::can ?>
                <?php if (\Entrust::can(['Permission Update','All'])) : ?>

                <li>
                    <a href="<?php echo e(url('/back/roles')); ?> "> <i class="menu-icon fa fa-hand-o-right"></i>Roles </a>
                </li>
                <?php endif; // Entrust::can ?>
                <?php if (\Entrust::can(['Permission Update','All'])) : ?>

                <li>
                    <a href="<?php echo e(url('/back/author')); ?> "> <i class="menu-icon fa  fa-user"></i>Authors </a>
                </li>
                <?php endif; // Entrust::can ?>

                <?php if (\Entrust::can(['Category List','All'])) : ?>

                <li>
                    <a href="<?php echo e(url('/back/categroies')); ?> "> <i class="menu-icon fa fa-folder"></i>Categories </a>
                </li>
                <?php endif; // Entrust::can ?>

                <?php if (\Entrust::can(['Post List','All'])) : ?>

                <li>
                    <a href="<?php echo e(url('/back/posts')); ?> "> <i class="menu-icon fa fa-comments "></i>Posts </a>
                </li>
                <?php endif; // Entrust::can ?>

                <?php if (\Entrust::can(['System Settings','All'])) : ?>
                <li>
                    <a href=" <?php echo e(url('/back/settings')); ?> "> <i class="menu-icon fa fa-gear"></i>Settings </a>
                </li>
                 <?php endif; // Entrust::can ?>

           
    </nav>
</aside><?php /**PATH C:\Users\Ayham\Desktop\MasterProject\MasterProject\resources\views/admin/layout/navigation.blade.php ENDPATH**/ ?>