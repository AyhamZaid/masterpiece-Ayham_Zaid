<?php $__env->startSection('content'); ?>
<section id="feature_news_section" class="feature_news_section">
    <div class="container">
       <div class="row">
           <div class="col-md-7">
               <div class="feature_article_wrapper">
                   <div class="feature_article_img">
<img class="img-responsive top_static_article_img" src="<?php echo e(asset('/post')); ?>/<?php echo e($hot_news->main_image); ?>"  alt="<?php echo e($hot_news->title); ?>">
                   </div>
                   <!-- feature_article_img -->

                   <div class="feature_article_inner">
                       <div class="tag_lg red"><a href="category.html">Hot News</a></div>
                       <div class="feature_article_title">
                           <h1><a href="<?php echo e(url('/details')); ?>/<?php echo e($hot_news->slug); ?>" target="_self"><?php echo e($hot_news->title); ?> </a></h1>
                       </div>
                        <!-- feature_article_title -->

<div class="feature_article_date">
   <a href="<?php echo e(url('/author')); ?>/<?php echo e($hot_news->creator->id); ?>" ><?php echo e($hot_news->creator->name); ?></a>,
     <?php echo e(date('F j,Y',strtotime( $hot_news->created_at ))); ?>           </a></div>
                       <!-- feature_article_date -->

                       <div class="feature_article_content">
                          <?php echo e($hot_news->short_description); ?>

                       </div>
                       <!-- feature_article_content -->

                       <div class="article_social">
                            
                           <span><i class="fa fa-comments-o"></i><a href="#"><?php echo e($hot_news->comments_count); ?></a>Comments</span>
                       </div>
                       <!-- article_social -->

                   </div>
                   <!-- feature_article_inner -->

               </div>
               <!-- feature_article_wrapper -->

           </div>
           <!-- col-md-7 -->
            <?php $__currentLoopData = $top_viewed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-5" style="margin-bottom: 3%">
               <div class="feature_static_wrapper">
                   <div class="feature_article_img">
                       <img class="img-responsive" width="450" style="height: 270px" src="<?php echo e(asset('post')); ?>/<?php echo e($item->main_image); ?>" alt="<?php echo e($item->title); ?>">
                   </div>
                   <!-- feature_article_img -->

                   <div class="feature_article_inner">
                       <div class="tag_lg purple"><a href="category.html">Top Viewed</a></div>
                       <div class="feature_article_title">
<h1><a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?>"><?php echo e(str_limit( $item->title,25,'..' )); ?> </a></h1>
                       </div>
                       <!-- feature_article_title -->

 <div class="feature_article_date"><a href="<?php echo e(url('/author')); ?>/<?php echo e($item->creator->id); ?>"  ><?php echo e($item->creator->name); ?></a>, <?php echo e(date('F j,Y',strtotime( $item->created_at ))); ?>   </div>
                       <!-- feature_article_date -->

                       <div class="feature_article_content">
                           <?php echo e(str_limit( $item->short_description,50,'...' )); ?>

                       </div>
                       <!-- feature_article_content -->

                       <div class="article_social">
                           
                           <span><i class="fa fa-comments-o"></i><a href="#"><?php echo e($item->comments_count); ?></a>Comments</span>
                       </div>
                       <!-- article_social -->

                   </div>
                   <!-- feature_article_inner -->

               </div>
               <!-- feature_static_wrapper -->

           </div>
           <!-- col-md-5 -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
           <!-- col-md-5 -->

       </div>
       <!-- Row -->

   </div>
   <!-- container -->

</section>
<!-- Feature News Section -->



<section id="category_section" class="category_section">
<div class="container">
<div class="row">
<div class="col-md-8">
<div class="category_section mobile">
    <?php $__currentLoopData = $shareData['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $category->posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($key === 0): ?>
  <div class="article_title header_purple">
      <h2><a href="<?php echo e(url('/category')); ?>/<?php echo e($category->id); ?>"><?php echo e($category->name); ?></a></h2>
  </div>
    <!----article_title------>
  
            <div class="category_article_wrapper">
                <div class="row">
                    <div class="col-md-6">
                        <div class="top_article_img">
                            <a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?>"><img class="img-responsive"
                  src="<?php echo e(asset('post')); ?>/<?php echo e($item->list_image); ?>" alt="<?php echo e($item->title); ?>">
                            </a>
                        </div>
                        <!----top_article_img------>
                    </div>
                    <div class="col-md-6">
                        <span class="tag purple"><?php echo e($category->name); ?></span>
        
                        <div class="category_article_title">
                            <h2><a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?>" target="_self"><?php echo e($item->title); ?> </a></h2>
                        </div>
                        <!----category_article_title------>
          <div class="category_article_date"> <a href="<?php echo e(url('/author')); ?>/<?php echo e($item->creator->id); ?>"  ><?php echo e($item->creator->name); ?></a>, <?php echo e(date('F j,Y',strtotime( $item->created_at ))); ?></div>
                        <!----category_article_date------>
                        <div class="category_article_content">
                            <?php echo e(str_limit( $item->short_description,100,'...' )); ?>

                        </div>
                        <!----category_article_content------>
                        <div class="media_social">
                             
                            <span><i class="fa fa-comments-o"></i><a href="#"><?php echo e(count($item->comments)); ?></a> Comments</span>
                        </div>
                        <!----media_social------>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <?php if($key === 1): ?>
            <div class="category_article_wrapper">
                <div class="row">
                    <?php endif; ?>
                    <div class="col-md-6" style="margin-bottom: 2%">
                        <div class="media">
                            <div class="media-left">
                                <a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?>"><img class="media-object" src="<?php echo e(asset('post')); ?>/<?php echo e($item->thumb_image); ?>"
                                                 alt="<?php echo e($item->title); ?>"></a>
                            </div>
                            <div class="media-body">
                                <span class="tag purple"><?php echo e($category->name); ?></span>
        
                                <h3 class="media-heading"><a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?>" ><?php echo e($item->title); ?></a></h3>
                                <span class="media-date"><a href="<?php echo e(url('/author')); ?>/<?php echo e($item->creator->id); ?>"  ><?php echo e($item->creator->name); ?></a>, <?php echo e(date('F j,Y',strtotime( $item->created_at ))); ?></span>
        
                                <div class="media_social">
                                    
                                    <span><a href="#"><i class="fa fa-comments-o"></i><?php echo e(count($item->comments)); ?></a> Comments</span>
                                </div>
                            </div>
                        </div>
                         
                    </div>
                   <?php if($loop->last): ?>
                </div>
            </div>
             <?php endif; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <p class="divider"><a href="<?php echo e(url('/category')); ?>/<?php echo e($category->id); ?>">More News&nbsp;&raquo;</a></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
<!-- Mobile News Section -->


<!-- Design News Section -->
</div>
<!-- Left Section -->

<div class="col-md-4">
<div class="widget">
    <div class="widget_title widget_black">
        <h2><a href="#">Most viewed</a></h2>
    </div>
    <?php $__currentLoopData = $shareData['most_viewed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="media">
        <div class="media-left">
        <a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?> "><img class="media-object" src="<?php echo e(asset('post')); ?>/<?php echo e($item->thumb_image); ?> " alt="<?php echo e($item->title); ?>"></a>
        </div>
        <div class="media-body">
            <h3 class="media-heading">
                <a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?>" ><?php echo e($item->title); ?></a>
            </h3> <span class="media-date"><a href="#"><?php echo e(date('j F -y',strtotime($item->created_at))); ?> </a>,  by: <a href="<?php echo e(url('/author')); ?>/<?php echo e($item->creator->id); ?>"><?php echo e($item->creator->name); ?> </a></span>

            <div class="widget_article_social">
              
                <span>
                    <a href="#" target="_self"><i class="fa fa-comments-o"></i><?php echo e(count($item->comments)); ?> </a> Comments
                </span>
            </div>
        </div>
    </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
    <p class="widget_divider"><a href="#" target="_self">More News&nbsp;&raquo;</a></p>
</div>
<!-- Popular News -->

<div class="widget hidden-xs m30">
    <img class="img-responsive adv_img" src="<?php echo e(asset('front')); ?>/img/right_add1.jpg" alt="add_one">
    <img class="img-responsive adv_img" src="<?php echo e(asset('front')); ?>/img/right_add2.jpg" alt="add_one">
    <img class="img-responsive adv_img" src="<?php echo e(asset('front')); ?>/img/right_add3.jpg" alt="add_one">
    <img class="img-responsive adv_img" src="<?php echo e(asset('front')); ?>/img/right_add4.jpg" alt="add_one">
</div>
<!-- Advertisement -->

<div class="widget hidden-xs m30">
    <img class="img-responsive widget_img" src="<?php echo e(asset('front')); ?>/img/right_add5.jpg" alt="add_one">
</div>
<!-- Advertisement -->


<!-- Reviews News -->

<div class="widget hidden-xs m30">
    <img class="img-responsive widget_img" src="<?php echo e(asset('front')); ?>/img/right_add6.jpg" alt="add_one">
</div>
<!-- Advertisement -->

<div class="widget m30">
    <div class="widget_title widget_black">
        <h2><a href="#">Most Commented</a></h2>
        <?php $__currentLoopData = $shareData['most_commented']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="media">
            <div class="media-left">
                <a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?>"><img class="media-object" src="<?php echo e(asset('post')); ?>/<?php echo e($item->thumb_image); ?>" alt="<?php echo e($item->title); ?>"></a>
            </div>
            <div class="media-body">
                <h3 class="media-heading">
                    <a href="<?php echo e(url('/details')); ?>/<?php echo e($item->slug); ?>" ><?php echo e($item->title); ?></a>
                </h3>
    
                <div class="media_social">
                    <span><i class="fa fa-comments-o"></i><a href="#"><?php echo e($item->comments_count); ?></a> Comments</span>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <p class="widget_divider"><a href="#" target="_self">More News&nbsp;&nbsp;&raquo; </a></p>
</div>
<!-- Most Commented News -->

<div class="widget m30">
    <div class="widget_title widget_black">
        <h2><a href="#">Editor Corner</a></h2>
    </div>
    <div class="widget_body"><img class="img-responsive left" src="<?php echo e(asset('front')); ?>/img/editor.jpg"
                                  alt="Generic placeholder image">

        <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C
            users after installed base benefits. Dramatically visualize customer directed convergence without</p>

        <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C
            users after installed base benefits. Dramatically visualize customer directed convergence without
            revolutionary ROI.</p>
        <button class="btn pink">Read more</button>
    </div>
</div>
<!-- Editor News -->

<div class="widget hidden-xs m30">
    <img class="img-responsive add_img" src="<?php echo e(asset('front')); ?>/img/right_add7.jpg" alt="add_one">
    <img class="img-responsive add_img" src="<?php echo e(asset('front')); ?>/img/right_add7.jpg" alt="add_one">
    <img class="img-responsive add_img" src="<?php echo e(asset('front')); ?>/img/right_add7.jpg" alt="add_one">
    <img class="img-responsive add_img" src="<?php echo e(asset('front')); ?>/img/right_add7.jpg" alt="add_one">
</div>
<!--Advertisement -->

<div class="widget m30">
    <div class="widget_title widget_black">
        <h2><a href="#">Readers Corner</a></h2>
    </div>
    <div class="widget_body"><img class="img-responsive left" src="<?php echo e(asset('front')); ?>/img/reader.jpg"
                                  alt="Generic placeholder image">

        <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C
            users after installed base benefits. Dramatically visualize customer directed convergence without</p>

        <p>Collaboratively administrate empowered markets via plug-and-play networks. Dynamically procrastinate B2C
            users after installed base benefits. Dramatically visualize customer directed convergence without
            revolutionary ROI.</p>
        <button class="btn pink">Read more</button>
    </div>
</div>
<!--  Readers Corner News -->

<div class="widget hidden-xs m30">
    <img class="img-responsive widget_img" src="<?php echo e(asset('front')); ?>/img/podcast.jpg" alt="add_one">
</div>
<!--Advertisement-->
</div>
<!-- Right Section -->

</div>
<!-- Row -->

</div>
<!-- Container -->

</section>
<!-- Category News Section -->

<section id="video_section" class="video_section">
    <div class="container">
        <div class="well">
            <div class="row">
                <div class="col-md-6">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/q3eFXeO62oo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                    </div>
                    <!-- embed-responsive -->

                </div>
                <!-- col-md-6 -->

                <div class="col-md-3">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/464puoD09dM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>                    </div>
                    <!-- embed-responsive -->

                    <div class="embed-responsive embed-responsive-4by3 m16">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/0pss7E6IF_8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                    <!-- embed-responsive -->

                </div>
                <!-- col-md-3 -->

                <div class="col-md-3">
                    <div class="embed-responsive embed-responsive-4by3">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/BxLMDxWHHlU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>                            </div>
                    <!-- embed-responsive -->

                    <div class="embed-responsive embed-responsive-4by3 m16">
                        <iframe width="560" height="315" src="https://www.youtube.com/embed/YLtEReSUt-k" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>                            </div>
                    <!-- embed-responsive -->

                </div>
                <!-- col-md-3 --

            </div>
            <!-- row -->

        </div>
        <!-- well -->

    </div>
    <!-- Container -->

</section>
<!-- Video News Section -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ayham\Desktop\MasterProject\MasterProject\resources\views/front/home.blade.php ENDPATH**/ ?>