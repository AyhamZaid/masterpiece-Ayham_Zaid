<?php $__env->startSection('content'); ?>
    
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/normalize.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/themify-icons.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/flag-icon.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/cs-skin-elastic.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/lib/datatable/dataTables.bootstrap.min.css">
<!-- <link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/bootstrap-select.less"> -->
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/scss/style.css">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>


<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1><?php echo e($page_name); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Table</a></li>
                    <li class="active">Data table</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

        <div class="col-md-12">
            <div class="card">
              <?php if($message = Session::get('success')): ?>
              <div class="alert alert-success" role="alert">
                   <?php echo e($message); ?>


              </div>
              <?php endif; ?>
                <div class="card-header">
                    <strong class="card-title"><?php echo e($page_name); ?></strong>
                    <?php if (\Entrust::can(['Post Add','All'])) : ?>
                    <a href="<?php echo e(url('/back/posts/create')); ?> " class="btn btn-primary pull-right">Create</a>
                    <?php endif; // Entrust::can ?>
                </div>
                <div class="card-body">
          <table id="bootstrap-data-table" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Image</th>
                <th>Title</th>
                <th>Authur</th>
                <th>Totle View</th>
                <th>Status</th>
                <th>Hot News</th>
                <th>Options</th>
              </tr>
            </thead>
            <tbody>
              
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(++$item); ?></td>
                <td>
                    <?php if(file_exists(public_path('/post/').$row->thumb_image)): ?>
                    <img src = "<?php echo e(asset('post')); ?>/<?php echo e($row->thumb_image); ?> "class="img img-responsive">
                    <?php endif; ?>
                </td>
                <td><?php echo e($row->title); ?></td>
                
                <td><?php echo e($row->creator->name ?? 'user not found'); ?> </td> 
                <td><?php echo e($row->view_count); ?> </td>
                <td>
                    <?php echo e(Form::open(['method'=>'PUT','url'=>['/back/post/status/'.$row->id],'style'=>'display:inline' ])); ?>

                    <?php if($row->status === 1): ?>
                      <?php echo e(Form::submit('Unpublish',['class'=>'btn btn-danger'])); ?>

                      <?php else: ?>
                      <?php echo e(Form::submit('Publish',['class'=>'btn btn-success'])); ?>

                    <?php endif; ?>
                      <?php echo e(Form::close()); ?>    
                </td>

                <td>
                  <?php echo e(Form::open(['method'=>'PUT','url'=>['/back/post/hot/news/'.$row->id],'style'=>'display:inline' ])); ?>

                  <?php if($row->hot_news === 1): ?>
                    <?php echo e(Form::submit('No',['class'=>'btn btn-danger'])); ?>

                    <?php else: ?>
                    <?php echo e(Form::submit('Yes',['class'=>'btn btn-success'])); ?>

                  <?php endif; ?>
                    <?php echo e(Form::close()); ?>    
              </td>
           
                <td> 
                  <?php if (\Entrust::can(['Post Add','All','Post Update'])) : ?> 
                  <a href="<?php echo e(url('/back/comment/'.$row->id)); ?> " class="btn btn-info">Comment</a>
                    <a href="<?php echo e(url('/back/post/edit/'.$row->id)); ?> " class="btn btn-primary">Edit</a>
                  <?php endif; // Entrust::can ?>
                  <?php if (\Entrust::can(['Post Add','All'])) : ?> 
                  <?php echo e(Form::open(['method'=>'DELETE','url'=>['/back/post/delete/'.$row->id],'style'=>'display:inline' ])); ?>

                  <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger'])); ?>

                  <?php echo e(Form::close()); ?>

                  <?php endif; // Entrust::can ?>

                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
                </div>
            </div>
        </div>


        </div>
    </div><!-- .animated -->
</div>


<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/datatables.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/jszip.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/pdfmake.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/vfs_fonts.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/buttons.print.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/buttons.colVis.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/datatables-init.js"></script>


<script type="text/javascript">
    $(document).ready(function() {
      $('#bootstrap-data-table-export').DataTable();
    } );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ayham\Desktop\MasterProject\MasterProject\resources\views/admin/post/list.blade.php ENDPATH**/ ?>