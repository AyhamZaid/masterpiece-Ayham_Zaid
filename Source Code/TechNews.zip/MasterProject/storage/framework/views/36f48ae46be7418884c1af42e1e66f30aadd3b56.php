<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang=""> <!--<![endif]-->
<head>
<?php echo $__env->make('admin.layout.top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <!-- Left Panel -->
<?php echo $__env->make('admin.layout.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /#left-panel -->
    <!-- Left Panel -->
    <!-- Right Panel -->
<div id="right-panel" class="right-panel">
     <!-- Header-->
<?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /header -->
    <!-- Header-->
<?php echo $__env->yieldContent('content'); ?>
    <!-- .content -->
</div><!-- /#right-panel -->
    <!-- Right Panel -->
<?php echo $__env->make('admin\layout\bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\MasterProject\resources\views/admin/layout/master.blade.php ENDPATH**/ ?>