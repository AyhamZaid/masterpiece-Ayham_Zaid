<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/lib/chosen/chosen.min.css">
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/chosen/chosen.jquery.js"></script>


<script>
    jQuery(document).ready(function() {
        jQuery(".myselect").chosen({
            disable_search_threshold: 10,
            no_results_text: "Oops, nothing found!",
            width: "100%"
        });
    });
   
</script>

<div class="row">
    <div class="col-md-12">
<div class="card">
    <div class="card-header">
        <strong class="card-title"><?php echo e($page_name); ?> </strong>
    </div>
    <div class="card-body">
      <!-- Credit Card -->
      <div id="pay-invoice">
          <div class="card-body">
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>
                <?php endif; ?>
                <hr>

                <?php echo e(Form::model($author,['route' => ['author-update',$author->id],'method'=>'put'])); ?>

                                             
                                                  
                <div class="form-group">
                    <?php echo e(Form::label('name', 'Name', array('class' => 'control-label mb-1'))); ?>            
                    <?php echo e(Form::text('name',null,['class'=>'form-control','id'=>'name'] )); ?>

                </div>
    
                <div class="form-group">
                    <?php echo e(Form::label('email', 'Email', array('class' => 'control-label mb-1'))); ?>       
                    <?php echo e(Form::email('email',null,['class'=>'form-control','id'=>'email'] )); ?>

                </div>
    
                <div class="form-group">
                    <?php echo e(Form::label('password', 'Password', array('class' => 'control-label mb-1'))); ?>        
                    <?php echo e(Form::password('password',['class'=>'form-control','id'=>'password'] )); ?>

                </div>
    
                <div class="form-group">
                    <?php echo e(Form::label('roles', 'Roles', array('class' => 'control-label mb-1'))); ?>           
                    <?php echo e(Form::select('roles[]',$roles,null,['class'=>'form-control myselect','data-placeholder'=>'Select Roles', 'multiple'] )); ?>

                </div> 
    
                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                    <i class="fa fa-lock fa-lg"></i>&nbsp;
                    <span id="payment-button-amount">Update</span>
                    <span id="payment-button-sending" style="display:none;">Sending…</span>
                </button>
    
                </div>
                                              <?php echo e(Form::close()); ?>

                                          </div>
                                      </div>
            
                                    </div>
                                </div> <!-- .card -->
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ayham\Desktop\MasterProject\MasterProject\resources\views/admin/author/edit.blade.php ENDPATH**/ ?>