<?php $__env->startSection('content'); ?>
    
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/normalize.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/font-awesome.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/themify-icons.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/flag-icon.min.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/cs-skin-elastic.css">
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/lib/datatable/dataTables.bootstrap.min.css">
<!-- <link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/css/bootstrap-select.less"> -->
<link rel="stylesheet" href="<?php echo e(asset('admin\assets')); ?>/scss/style.css">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>


<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1><?php echo e($page_name); ?></h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="#">Dashboard</a></li>
                    <li><a href="#">Table</a></li>
                    <li class="active">Data table</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

        <div class="col-md-12">
            <div class="card">
              <?php if($message = Session::get('sucsses')): ?>
              <div class="alert alert-success" role="alert">
                   <?php echo e($message); ?>


              </div>
              <?php endif; ?>
                <div class="card-header">
                    <strong class="card-title"><?php echo e($page_name); ?></strong>
                    <a href="<?php echo e(url('/back/author/create')); ?> " class="btn btn-primary pull-right">Create</a>
                </div>
                <div class="card-body">
          <table id="bootstrap-data-table" class="table table-striped table-bordered">
            <thead>
              <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Option</th>
              </tr>
            </thead>
            <tbody>
              
              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e(++$item); ?></td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e($row->email); ?></td>
                <td>
                  <?php if($row->roles()->get()): ?>
                  <ul style="padding: 20px;margin: 20px">
                   <?php $__currentLoopData = $row->roles()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <li> <?php echo e($role->name); ?> </li>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
                 </ul> 
                   <?php endif; ?>
                
                </td>
                <td> 
                  <a href="<?php echo e(url('/back/author/edit/'.$row->id)); ?> " class="btn btn-primary">Edit</a>
                  <?php echo e(Form::open(['method'=>'DELETE','url'=>['/back/author/delete/'.$row->id],'style'=>'display:inline'])); ?>

                  <?php echo e(Form::submit('Delete',['class'=>'btn btn-danger'])); ?>

                  <?php echo e(Form::close()); ?>

                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
                </div>
            </div>
        </div>


        </div>
    </div><!-- .animated -->
</div>


<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/datatables.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/dataTables.bootstrap.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/dataTables.buttons.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/buttons.bootstrap.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/jszip.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/pdfmake.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/vfs_fonts.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/buttons.html5.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/buttons.print.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/buttons.colVis.min.js"></script>
<script src="<?php echo e(asset('admin\assets')); ?>/js/lib/data-table/datatables-init.js"></script>


<script type="text/javascript">
    $(document).ready(function() {
      $('#bootstrap-data-table-export').DataTable();
    } );
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ayham\Desktop\MasterProject\MasterProject\resources\views/admin/author/list.blade.php ENDPATH**/ ?>