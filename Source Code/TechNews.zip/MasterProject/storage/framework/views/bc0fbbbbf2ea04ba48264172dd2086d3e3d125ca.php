
<!-- jquery Core-->
<script src="<?php echo e(asset('front')); ?>/js/jquery-2.1.4.min.js"></script>

<!-- Bootstrap -->
<script src="<?php echo e(asset('front')); ?>/js/bootstrap.min.js"></script>

<!-- Theme Menu -->
<script src="<?php echo e(asset('front')); ?>/js/mobile-menu.js"></script>

<!-- Owl carousel -->
<script src="<?php echo e(asset('front')); ?>/js/owl.carousel.min.js"></script>

<!-- Theme Script -->
<script src="<?php echo e(asset('front')); ?>/js/script.js"></script><?php /**PATH C:\xampp\htdocs\MasterProject\resources\views/front/layout/bottom.blade.php ENDPATH**/ ?>