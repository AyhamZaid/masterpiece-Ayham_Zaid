<?php $__env->startSection('content'); ?>

<div class="row">
<div class="col-md-12">
   

<div class="card">
                      <div class="card-header">
                          <strong class="card-title"> <?php echo e($page_name); ?> </strong>
                      </div>
                      <div class="card-body">
                        <!-- Credit Card -->
                        <div id="pay-invoice">
                            <div class="card-body">
                  <?php if(count($errors) > 0): ?>
                  <div class="alert alert-danger" role="alert">
                    <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li> <?php echo e($error); ?> </li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
 
                </div>
                  <?php endif; ?>

                                
                                <hr>

  <?php echo e(Form::model($category,['route' => ['category-update',$category->id],'method'=>'put'])); ?>

                               
                                    
                        <div class="form-group">
          <?php echo e(Form::label('name', 'Name', array('class' => 'control-label mb-1'))); ?>

                                    
          <?php echo e(Form::text('name',null,['class'=>'form-control','id'=>'name'] )); ?>

                              </div>

                              

              <div>
                  <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                      <i class="fa fa-lock fa-lg"></i>&nbsp;
                      <span id="payment-button-amount">Update</span>
                      <span id="payment-button-sending" style="display:none;">Sending…</span>
                  </button>
              </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div>

                      </div>
                  </div> <!-- .card -->


  </div>
 
</div>

 <?php $__env->stopSection(); ?>                 
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ayham\Desktop\MasterProject\MasterProject\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>