
<!-- jquery Core-->
<script src="{{asset('front')}}/js/jquery-2.1.4.min.js"></script>

<!-- Bootstrap -->
<script src="{{asset('front')}}/js/bootstrap.min.js"></script>

<!-- Theme Menu -->
<script src="{{asset('front')}}/js/mobile-menu.js"></script>

<!-- Owl carousel -->
<script src="{{asset('front')}}/js/owl.carousel.min.js"></script>

<!-- Theme Script -->
<script src="{{asset('front')}}/js/script.js"></script>