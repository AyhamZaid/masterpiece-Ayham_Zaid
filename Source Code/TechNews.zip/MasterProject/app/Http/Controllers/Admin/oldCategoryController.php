<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{
    public function index(){
        return view('Admin.category.list');
    }

    public function create(){
        return view('Admin.category.create');
    }

    public function edit(){
        return view('Admin.category.edit');
    }
}
